public class EstruturaVaziaException extends Exception {
    public EstruturaVaziaException(){
        super("Estrutura Vazia");
    }
}